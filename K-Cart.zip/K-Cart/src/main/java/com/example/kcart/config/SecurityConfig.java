package com.example.kcart.config;

import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.*;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.web.SecurityFilterChain;

import com.example.kcart.services.UserService;

@Configuration
@EnableWebSecurity
public class SecurityConfig {
	
	@Value("${security.jwt.secret-key}")
	private String jwtsecretkey;

	@Bean
	public SecurityFilterChain securityfilterchain(HttpSecurity http) throws Exception
	{
		return http
				.csrf(csrf->csrf.disable())
				.authorizeHttpRequests(auth->auth
				.requestMatchers("/").permitAll()
				.requestMatchers("/dashboard/**").permitAll()
				.requestMatchers("/account").permitAll()
				.requestMatchers("/accounts/login").permitAll()
				.requestMatchers("/accounts/signup").permitAll()
				.anyRequest().authenticated()
				)
				.oauth2ResourceServer(oauth2->oauth2.jwt(Customizer.withDefaults()))
				.sessionManagement(session->session.sessionCreationPolicy(
						SessionCreationPolicy.STATELESS))
				.build();
	}
	
	
	@Bean
	public JwtDecoder jwtDecoder()
	{
		var secretkey=new SecretKeySpec(jwtsecretkey.getBytes(),"");
		return NimbusJwtDecoder.withSecretKey(secretkey).macAlgorithm(MacAlgorithm.HS256).build();
	}
	
	@Bean
	public AuthenticationManager authenticationManager(UserService serv)
	{
		DaoAuthenticationProvider provider=new DaoAuthenticationProvider();
		provider.setUserDetailsService(serv);
		provider.setPasswordEncoder(new BCryptPasswordEncoder());
		return new ProviderManager(provider);
	}
	
}
