package com.example.kcart.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.example.kcart.models.User;
import com.example.kcart.repos.UserRepos;

public class UserService implements UserDetailsService {

	@Autowired
	private UserRepos repo;
	
	
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User _user=repo.findByUsername(username);
		if(_user!=null)
		{
			return org.springframework.security.core.userdetails.User.withUsername(
					_user.getUsername())
					.password(_user.getPassword())
					.roles(_user.getRole())
					.build();
		}
		return null;
	}

}
