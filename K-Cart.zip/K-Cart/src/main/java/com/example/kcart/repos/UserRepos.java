package com.example.kcart.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.kcart.models.User;

public interface UserRepos extends JpaRepository<User, Integer> {
	
	User findByUsername(String username);
	User findByEmail(String email);

}
