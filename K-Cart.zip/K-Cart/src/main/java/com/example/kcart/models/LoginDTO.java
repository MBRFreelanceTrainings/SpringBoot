package com.example.kcart.models;

import lombok.*;

@Getter
@Setter
public class LoginDTO {
	private String username;
	private String password;

}
