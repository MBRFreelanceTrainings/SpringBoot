package com.example.kcart.controllers;

import java.time.Instant;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import org.springframework.security.oauth2.jwt.JwsHeader;
import org.springframework.security.oauth2.jwt.JwtClaimsSet;
import org.springframework.security.oauth2.jwt.JwtEncoderParameters;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtEncoder;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.kcart.models.LoginDTO;
import com.example.kcart.models.SignupDTO;
import com.example.kcart.models.User;
import com.example.kcart.repos.UserRepos;
import com.nimbusds.jose.jwk.source.ImmutableSecret;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/accounts")
public class AccountsController {
	
	@Autowired
	private UserRepos repo;
	
	@Autowired
	private AuthenticationManager authmanager;

	@Value("${security.jwt.secret-key}")
	private String jwtSecretKey;
	
	@Value("${security.jwt.issuer}")
	private String jwtIssuer;
	
	private String createJwtToken(User user)
	{
		Instant now=Instant.now();
		JwtClaimsSet claims=JwtClaimsSet.builder()
				.issuer(jwtIssuer)
				.issuedAt(now)
				.expiresAt(now.plusSeconds(24*3600))
				.subject(user.getUsername())
				.claim("role", user.getRole())
				.build();
		var encoder=new NimbusJwtEncoder(new ImmutableSecret<>(jwtSecretKey.getBytes()));
		var params=JwtEncoderParameters.from(JwsHeader.with(MacAlgorithm.HS256).build(),claims);
		
		return encoder.encode(params).getTokenValue();
	}
	
	@PostMapping("/signup")
	public ResponseEntity<Object> Signup(@Valid @RequestBody SignupDTO dto,BindingResult result)
	{
		if(result.hasErrors())
		{
			var errorList=result.getAllErrors();
			var errorMap=new HashMap<String,String>();
			for(int i=0;i<errorList.size();i++)
			{
				var error=(FieldError) errorList.get(i);
				errorMap.put(error.getField(), error.getDefaultMessage());
			}
			return ResponseEntity.badRequest().body(errorMap);
		}
		
		var bCryptEncoder=new BCryptPasswordEncoder();
		User user=new User();
		user.setFirstname(dto.getFirstname());
		user.setLastname(dto.getLastname());
		user.setEmail(dto.getEmail());
		user.setUsername(dto.getUsername());
		user.setPassword(bCryptEncoder.encode(dto.getPassword()));
		user.setRole("client");
		try {
			var existingUser=repo.findByUsername(dto.getUsername());
			if(existingUser!=null)
			{
				return ResponseEntity.badRequest().body("Username Already Taken!");
			}
			
			
			existingUser=repo.findByEmail(dto.getEmail());
			if(existingUser!=null)
			{
				return ResponseEntity.badRequest().body("Email Already Registered With Us!");
			}
			
			repo.save(user);
			
			String jwtToken=createJwtToken(user);
			var Response=new HashMap<String,Object>();
			Response.put("token",jwtToken);
			Response.put("user",user);
			return ResponseEntity.ok(Response);
		}
		catch(Exception ex)
		{
			System.out.println("Error:");
			ex.printStackTrace();
		}
		
		return ResponseEntity.badRequest().body("Error");
	}
	
	
	@PostMapping("/login")
	public ResponseEntity<Object> Login(@Valid @RequestBody LoginDTO dto,BindingResult result)
	{
		if(result.hasErrors())
		{
			var errorList=result.getAllErrors();
			var errorMap=new HashMap<String,String>();
			for(int i=0;i<errorList.size();i++)
			{
				var error=(FieldError) errorList.get(i);
				errorMap.put(error.getField(), error.getDefaultMessage());
			}
			return ResponseEntity.badRequest().body(errorMap);
		}
		
		try {
			authmanager.authenticate(new UsernamePasswordAuthenticationToken(
					dto.getUsername(),dto.getPassword()));
			User user=repo.findByUsername(dto.getUsername());
			
			String jwtToken=createJwtToken(user);
			var Response=new HashMap<String,Object>();
			Response.put("token",jwtToken);
			Response.put("user",user);
			return ResponseEntity.ok(Response);
			
		}
		catch(Exception ex)
		{
			System.out.println("Error:");
			ex.printStackTrace();
		}
		return ResponseEntity.badRequest().body("Incorrect Username/Password");
	}
	
	
	@GetMapping("/profile")
	public ResponseEntity<Object> Profile(Authentication auth)
	{
		var Response=new HashMap<String,Object>();
		Response.put("Username",auth.getName());
		Response.put("Authorities",auth.getAuthorities());
		var user=repo.findByUsername(auth.getName());
		Response.put("User", user);
		return ResponseEntity.ok(Response);
	}
}
