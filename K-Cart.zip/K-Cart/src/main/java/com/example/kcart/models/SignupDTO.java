package com.example.kcart.models;

import jakarta.validation.constraints.*;
import lombok.*;


@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor	
public class SignupDTO {
	@NotEmpty
	private String firstname;
	
	@NotEmpty
	private String lastname;
	
	@NotEmpty
	private String username;
	
	@NotEmpty
	private String email;
	
	@NotEmpty
	@Size(min = 6,max = 25,message = "Min of 6 Characters and Max of 25")
	private String password;
}
