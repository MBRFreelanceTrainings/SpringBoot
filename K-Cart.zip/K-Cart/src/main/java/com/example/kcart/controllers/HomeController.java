package com.example.kcart.controllers;

import org.springframework.web.bind.annotation.*;

@RestController
public class HomeController {

	@GetMapping("/")
	public String Home()
	{
		return "Home Page";
	}
	
	@GetMapping("/dashboard")
	public String Dashboard()
	{
		return "Product Dashboard Page";
	}
	
	@GetMapping("/admin")
	public String Admin()
	{
		return "Admin Dashboard Page";
	}
	
	@GetMapping("/user")
	public String User()
	{
		return "User Home Page";
	}
	
}
