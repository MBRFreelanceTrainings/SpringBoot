package com.sample.validations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
