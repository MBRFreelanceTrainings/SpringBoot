package com.sample.validations;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;

@RestController
public class UserController {
	
	@PostMapping("/users")
	public ResponseEntity<String> addUser(@Valid @RequestBody User user)
	{
		return new ResponseEntity<String>("User is Valid",HttpStatus.OK);
	}
}
