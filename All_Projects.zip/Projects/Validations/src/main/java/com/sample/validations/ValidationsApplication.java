package com.sample.validations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValidationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ValidationsApplication.class, args);
	}

}
