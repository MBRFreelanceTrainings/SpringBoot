package com.sample.validations;

import jakarta.validation.constraints.*;
import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class User {

	private int id;
	
	@NotEmpty(message = "Name is Required")
	@Size(min = 8,max = 20,message = "Name Must be min 8 and max 20")
	private String name;
	
	@NotEmpty(message = "E-Mail is Required")
	@Email(message = "Invalid E-mail")
	private String email;
	
	@NotEmpty(message = "Mobile is Required")
	@Pattern(regexp = "^[6-9]{1}[0-9]{9}$",message = "Invalid Mobile No.")
	private String mobile;
	
     @NotNull(message = "Age Should Not be Empty")
     @Min(value=18,message = "Age should be min 18")
     @Max(value=60,message = "Age should be below 60")
     @Positive(message = "Age should be a positive number")
	private int age;
}
