package com.sample;

public interface IBank {
	void getROI();
}
