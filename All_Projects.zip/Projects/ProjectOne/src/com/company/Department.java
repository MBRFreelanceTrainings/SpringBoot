package com.company;

public class Department {
	private int Did;
	private String DName;
	
	public int getDid() {
		return Did;
	}
	public void setDid(int did) {
		Did = did;
	}
	public String getDName() {
		return DName;
	}
	public void setDName(String dName) {
		DName = dName;
	}
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Department(int did, String dName) {
		super();
		Did = did;
		DName = dName;
	}
	
	@Override
	public String toString() {
		return "Department [Did=" + Did + ", DName=" + DName + "]";
	}
	
	
	
}
