package com.sample.employeesapi.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.sample.employeesapi.models.Employee;
import com.sample.employeesapi.repos.EmployeesRepo;

public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeesRepo repo;

	@Override
	public List<Employee> GetAllEmployees() {
		return repo.findAll();
	}

	@Override
	public Employee GetEmployeeById(int id) {
		Employee emp=new Employee();
		try {
			emp=repo.findById(id).get();
		}
		catch(Exception ex)
		{
			
		}
		
		return emp;
	}

	@Override
	public Employee AddEmployee(Employee emp) {
		return repo.save(emp);
	}

	@Override
	public Employee updateEmployee(int id, Employee emp) {
		return repo.save(emp);
	}

	@Override
	public void DeleteEmployee(int id) {
		repo.deleteById(id);

	}

	@Override
	public Page<Employee> getEmployees(Pageable pageable) {
		return repo.findAll(pageable);
	}

}
