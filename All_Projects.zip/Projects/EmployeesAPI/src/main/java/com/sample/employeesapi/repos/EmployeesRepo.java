package com.sample.employeesapi.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sample.employeesapi.models.Employee;

public interface EmployeesRepo extends JpaRepository<Employee, Integer> {

}
