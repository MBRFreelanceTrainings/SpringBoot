package com.sample.employeesapi.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import com.sample.employeesapi.models.Employee;
import com.sample.employeesapi.services.EmployeeService;

@RestController
@RequestMapping("/api/employees")
public class EmployeesController {
	
	@Autowired
	private EmployeeService serv;
	
	@GetMapping
	public ResponseEntity<List<Employee>> GetAllEmployees()
	{
		List<Employee> emps=serv.GetAllEmployees();
		return ResponseEntity.status(HttpStatus.OK).body(emps);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Employee> GetEmployeeById(@PathVariable("id") int id)
	{
		Employee emp=serv.GetEmployeeById(id);
		if(emp.getId()!=0)
		{
			return ResponseEntity.status(HttpStatus.OK).body(emp);
		}
		else
		{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
	}
	
	@PostMapping
	public ResponseEntity<Employee> AddEmployee(@RequestBody Employee emp)
	{
		Employee employee=serv.AddEmployee(emp);
		return ResponseEntity.status(HttpStatus.OK).body(employee);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable("id") int id, @RequestBody Employee emp)
	{
		Employee employee=serv.updateEmployee(id,emp);
		return ResponseEntity.status(HttpStatus.OK).body(employee);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Employee> DeleteEmployee(@PathVariable("id") int id)
	{
		Employee emp=new Employee();
		emp=serv.GetEmployeeById(id);
		if(emp.getId()!=0)
		{
			serv.DeleteEmployee(id);
			return ResponseEntity.status(HttpStatus.OK).body(emp);
		}
		else
		{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
	}
	
	
	@GetMapping("/pages")
	public ResponseEntity<Page<Employee>> getEmployeesByPages(
			@RequestParam(defaultValue = "0") int page,
			@RequestParam(defaultValue = "1") int size,
			@RequestParam(defaultValue = "id")String sortBy
			)
	{
		Pageable pageable=PageRequest.of(page, size, Sort.by(sortBy));
		Page<Employee> emps=serv.getEmployees(pageable);
		return ResponseEntity.status(HttpStatus.OK).body(emps);
	}
	
	
}
