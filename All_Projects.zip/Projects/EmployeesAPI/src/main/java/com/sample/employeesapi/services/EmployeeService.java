package com.sample.employeesapi.services;

import java.util.List;

import org.springframework.data.domain.*;

import com.sample.employeesapi.models.Employee;

public interface EmployeeService {
	
	List<Employee> GetAllEmployees();
	Employee GetEmployeeById(int id);
	Employee AddEmployee(Employee emp);
	Employee updateEmployee(int id,Employee emp);
	void DeleteEmployee(int id);
	Page<Employee> getEmployees(Pageable pageable);
}
