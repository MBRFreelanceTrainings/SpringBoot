package com.sample.productsapi.models;

import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Product {
	private int id;
	
	private String name;
	
	private double price;
	

}
