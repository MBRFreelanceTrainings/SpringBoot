package com.sample.errorhandling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ErrorHandlingApplicationTests {

	@Test
	void contextLoads() {
	}

}
