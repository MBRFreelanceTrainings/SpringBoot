package com.sample.errorhandling;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

	
	@GetMapping("/test")
	public String Test()
	{
	  if(false)
	  {
		  throw new MyException("Something Went Wrong!");
	  }
	  return "Hello User!";
	}
}
