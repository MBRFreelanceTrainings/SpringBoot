package com.sample.security.basic;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

	@GetMapping("/private")
	public String privateEndPoint()
	{
		return "This is Working!";
	}
	
	@GetMapping("/public")
	public String publicEndPoint()
	{
		return "Public Endpoint is Working!";
	}
}
