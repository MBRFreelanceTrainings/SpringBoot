package com.sample.myfirstspringbootapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyfirstspringbootappApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyfirstspringbootappApplication.class, args);
	}

}
