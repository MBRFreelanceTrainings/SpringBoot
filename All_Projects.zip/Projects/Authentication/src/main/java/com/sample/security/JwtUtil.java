package com.sample.security;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.security.core.userdetails.UserDetails;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class JwtUtil {
   private final String SECRET_KEY="";
   private final long Expity_Time=1000*60*60;
   
   public String GenerateToken(UserDetails userDetails)
   {
	   Map<String,Object> claims=new HashMap<>();
	   return createToken(claims, userDetails.getUsername());
   }
   
   private String createToken(Map<String,Object> claims,String subject)
   {
	   return Jwts.builder()
			   .setClaims(claims)
			   .setSubject(subject)
			   .setIssuedAt(new Date(System.currentTimeMillis()))
			   .setExpiration(new Date(System.currentTimeMillis()+Expity_Time))
			   .signWith(SignatureAlgorithm.HS256,SECRET_KEY)
			   .compact();
   }
   
   private Claims extractAllClaims(String token)
   {
	   return Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token).getBody();
   }
   
   public String extractUsername(String token)
   {
	   return extractAllClaims(token).getSubject();
   }
   private boolean isTokenExpired(String token)
   {
	   try {
		   return extractAllClaims(token).getExpiration().before(new Date());
		   
	   }catch(ExpiredJwtException ex)
	   {
		   return true;
	   }
   }
   
   private boolean validateToken(String token,UserDetails userDetails)
   {
	   final String username=extractUsername(token);
	   return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
   }
}
