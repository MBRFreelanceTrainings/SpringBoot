package com.sample.security;

public class SecurityConfigurer {

}
