package com.sample.productsapi.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sample.productsapi.models.Product;

@RestController
@RequestMapping("/api/products")
public class ProductsController {
	public static List<Product> ProductList = new ArrayList<>();
	static {
		ProductList.add(new Product(1, "Iphone 13", 38000));
		ProductList.add(new Product(2, "Iphone 13 Mini", 32000));
		ProductList.add(new Product(3, "Samsung S24", 98000));
		ProductList.add(new Product(4, "Vivo V30", 31000));
		ProductList.add(new Product(5, "Redmi 13 Pro", 24000));
	}

	@GetMapping
	public ResponseEntity<List<Product>> GetProducts() {
		return ResponseEntity.ok(ProductList);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Product> GetProductById(@PathVariable("id") int id) {
		Product Product = new Product();
		for (Product prod : ProductList) {
			if (prod.getId() == id) {
				Product = prod;
			}
		}
		if (Product.getId() != 0) {
			return ResponseEntity.ok(Product);
		} else {
			return new ResponseEntity("Product Not Found with Given Id", HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping
	public ResponseEntity<Product> AddProduct(@RequestBody Product prod) {
		prod.setId(ProductList.size() + 1);
		ProductList.add(prod);
		return ResponseEntity.status(HttpStatus.CREATED).body(prod);
	}

	@PutMapping("/{id}")
	public ResponseEntity<Product> UpdateProduct(@PathVariable("id") int id, @RequestBody Product prod) {
		if (id == prod.getId()) {
			int count = 0;
			for (Product pr : ProductList) {
				if (pr.getId() == id) {
					count++;
					pr.setName(prod.getName());
					pr.setPrice(prod.getPrice());
				}
			}

			if (count > 0) {
				return ResponseEntity.status(HttpStatus.OK).body(prod);
			} else {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
			}
		} else {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
		}
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Product> DeleteProduct(@PathVariable("id") int id)
	{
		Product Product = new Product();
		int count=0;
		for (Product prod : ProductList) {
			if (prod.getId() == id) {
				count++;
				Product = prod;
			}
		}
		if (count > 0) {
			ProductList.remove(Product);
			return ResponseEntity.status(HttpStatus.OK).body(Product);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
	}

}
