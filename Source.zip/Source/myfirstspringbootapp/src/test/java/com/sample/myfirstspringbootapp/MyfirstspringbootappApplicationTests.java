package com.sample.myfirstspringbootapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyfirstspringbootappApplicationTests {

	@Test
	void contextLoads() {
	}

}
