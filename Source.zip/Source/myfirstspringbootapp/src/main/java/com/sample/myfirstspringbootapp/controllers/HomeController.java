package com.sample.myfirstspringbootapp.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/products")
public class HomeController {
	
	@GetMapping("/")
	public String SayHi()
	{
		return "Hi User... Welcome!";
	}
	
	@GetMapping("/test/{id}")
	public ResponseEntity<String> Test(@PathVariable("id") int id)
	{
		if(id<=100)
		{
			return new ResponseEntity<String>("Found Product",HttpStatus.OK);
		}
		else
		{		
		//return new ResponseEntity<String>("Product Not Found",HttpStatus.NOT_FOUND);
		//return ResponseEntity.notFound().build();
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No PRoduct Found!");
		}
	}
	
	@PostMapping("/")
	public ResponseEntity<String> AddProduct(
			@RequestParam("id") int id,
			@RequestParam("name") String name,
			@RequestParam("price") double price
			)
	{
		//return new ResponseEntity<String>("Record Saved",HttpStatus.CREATED);
		return ResponseEntity.status(201).body("Record Saved");
	}
	
}
