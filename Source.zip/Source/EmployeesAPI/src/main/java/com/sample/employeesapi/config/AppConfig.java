package com.sample.employeesapi.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.sample.employeesapi.services.EmployeeService;
import com.sample.employeesapi.services.EmployeeServiceImpl;

@Configuration
public class AppConfig {

	@Bean
	public EmployeeService getEmployeeService()
	{
		return new EmployeeServiceImpl();
	}
}
