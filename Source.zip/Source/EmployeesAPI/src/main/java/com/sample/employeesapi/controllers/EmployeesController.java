package com.sample.employeesapi.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import com.sample.employeesapi.models.Employee;
import com.sample.employeesapi.services.EmployeeService;

@RestController
@RequestMapping("/api/employees")
public class EmployeesController {
	
	@Autowired
	private EmployeeService serv;
	
	@GetMapping
	public ResponseEntity<List<Employee>> GetAllEmployees()
	{
		List<Employee> emps=serv.GetAllEmployees();
		return ResponseEntity.status(HttpStatus.OK).body(emps);
	}
}
