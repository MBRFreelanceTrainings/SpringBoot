package com.sample.employeesapi.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.sample.employeesapi.models.Employee;
import com.sample.employeesapi.repos.EmployeesRepo;

public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeesRepo repo;

	@Override
	public List<Employee> GetAllEmployees() {
		return repo.findAll();
	}

	@Override
	public Employee GetEmployeeById(int id) {
		return repo.findById(id).get();
	}

	@Override
	public Employee AddEmployee(Employee emp) {
		return repo.save(emp);
	}

	@Override
	public Employee updateEmployee(int id, Employee emp) {
		return repo.save(emp);
	}

	@Override
	public void DeleteEmployee(int id) {
		repo.deleteById(id);

	}

}
