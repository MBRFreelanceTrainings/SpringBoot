package com.company;

import org.springframework.context.annotation.*;

@Configuration
public class AppConfig {

	@Bean
	public Department getDepartment()
	{
		return new Department(9001,"IT-Dev");
	}
	
	@Bean
	public Employee getEmployee()
	{
		return new Employee(101, "Krishna", 65000, getDepartment());
	}	
	
}
