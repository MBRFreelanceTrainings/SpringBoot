package com.sample;

public class CITI implements IBank {
	
	@Override
	public void getROI()
    {
   	 System.out.println("This is From CITI Class");
    }
}
