package com.sample;

public class HSBC implements IBank {
	
	@Override
     public void getROI()
     {
    	 System.out.println("This is From HSBC Class");
     }
}
